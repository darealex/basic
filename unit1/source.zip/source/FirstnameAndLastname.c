/*
 Create console application that prints your first and last name, each at a separate line
 */ 

#include <stdio.h>

int main(){
	printf("Alex\nAsenov\n");
	return 0;
}
