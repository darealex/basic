/*
 Create a console application that calculates and prints the square root of the number 12345. Search in Internet
"how to calculate square root in C"
 */ 

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() { 
    double res = sqrt(12345.0);
    printf("%f", res);
    return 0;
}
