/*
 Create, compile and run a "Hello, C" console application. Make sure you include the standard Input/Output library
definition "stdio.h" in your source code. You should submit the source code folder (holding .c files) as part of your
homework.
 */
 
#include <stdio.h>

int main()
{
	printf("Hello C!\n");
	return 0;
}
