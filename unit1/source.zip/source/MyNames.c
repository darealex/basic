/*
 Modify the previous program to print your name
 */
#include <stdio.h>

int main(){
	printf("My name is Alex.\n");
	return 0;
}
