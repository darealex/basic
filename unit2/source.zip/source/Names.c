/* 
Declare two string (char array) variables holding your first name and last name. Print them in the console (mind
adding an interval between them).
 */


#include <stdio.h>  

int main() {
    char names[] = "Alex Asenov";
    printf("%s", names);
    return 0;
}
