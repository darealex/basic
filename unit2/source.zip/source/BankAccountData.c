/*   
 A bank account has a holder name (first name, middle name and last name), available amount of money (balance),
bank name, IBAN and 3 credit card numbers associated with the account. Declare the variables needed to keep the
information for a single bank account using the appropriate data types and descriptive names.
 */


#include <stdio.h>  

int main() {

    char first[] = "Alex";
    char middle[] = "Luibomirov";
    char last[] = "Asenov";
    double amountBalance = 0.000001;
    char bankName[] = "OBB";
    char ISBN[] = "BGOBB 3555 - 1554 - 456457485";
    unsigned long long creditNumbera = 365536589564124;
    unsigned long long creditNumberb = 365536589564124;
    unsigned long long creditNumberc = 365536589564124;  

     
    return 0;
}
