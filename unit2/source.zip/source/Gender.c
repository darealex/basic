/* 
Declare a variable called isFemale and assign an appropriate value corresponding to your gender. Print it on the
console 
 */


#include <stdio.h> 
//#include <stdbool.h> is c99

typedef int bool;
#define true 1;
#define false 0;

int main() {
    bool isFamale = false;
    printf(isFamale);
    return 0;
}
