/* 
Declare an integer variable and assign it with the value 254 in hexadecimal format (0x##). Use a calculator online to
find its hexadecimal representation. Print the variable and ensure that the result is "254"
 */


#include <stdio.h> 

int main() { 
    unsigned int syn = 0xFE;
    printf("%d\n", syn);
    return 0;
}
